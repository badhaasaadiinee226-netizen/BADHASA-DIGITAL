# BADHASA DIGITAL — Telegram + Website starter

One responsive app for a normal HTTPS website and Telegram Mini App, sharing one backend/database.

## Included starter
- Blue and white mobile-first interface
- Website username + private numeric code registration/login
- Telegram Mini App login endpoint with server-side initData validation
- Separate user accounts, persistent profiles and demo coin balance
- Demo Tap Tap reward with daily limit
- Text feed prototype

## Not yet production-ready
Real cash earnings, withdrawals, Telebirr, E-Birr, Visa/card, ATM payouts, video/photo uploads, private inbox, full moderation and admin panel are not implemented. Demo coins have no cash value. Do not promise fixed dollar rewards for views/likes/follows/taps without verified revenue and funded payout reserves. Do not charge users an advance fee to release withdrawals.

## Run
Install Node.js, run `npm install`, set a long random SESSION_SECRET, then `npm start`.

## Publish both
Deploy to a Node.js host with HTTPS and persistent storage. Set BOT_TOKEN privately in hosting settings. Create a new Telegram bot with the official @BotFather, then configure its Mini App/menu button to the deployed HTTPS URL. The same URL works as the website and Telegram Mini App. Use a persistent database/storage and backups before public launch.
